import {Injectable} from '@angular/core';
import {categories} from './data';
import {faqs} from './data';
import {Observable,of} from 'rxjs';
export class ModalService
{
getCategories() : Observable<String[]>
{
    return of(categories)
}
getFaqs() : Observable<any>
{
return of(faqs)

}

}
