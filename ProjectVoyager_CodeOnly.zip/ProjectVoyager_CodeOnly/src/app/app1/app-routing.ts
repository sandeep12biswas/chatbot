import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ModalComponent} from './../modal/modal.component';


const appRoutes: Routes = [
{path: '', component:ModalComponent},

//otherwise redirect to home
{path:'*', redirectTo: ''}

];

//@NgModule({
//  imports: [RouterModule.forRoot(routes)],
 // exports: [RouterModule]
//})
//export class AppRoutingModule { }

export const routing= RouterModule.forRoot(appRoutes);
