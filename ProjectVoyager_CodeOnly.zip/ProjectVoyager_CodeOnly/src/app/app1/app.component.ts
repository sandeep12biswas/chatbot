import { Component, OnInit } from '@angular/core';
import { ModalService } from '../modal.service'; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponents implements OnInit{
  private bodyText : string;
  title = 'projectVoyager';
constructor(private modelService : ModalService)
{


}
ngOnInit()
{
this.bodyText="this text can be updated on model 1s"

}
}

