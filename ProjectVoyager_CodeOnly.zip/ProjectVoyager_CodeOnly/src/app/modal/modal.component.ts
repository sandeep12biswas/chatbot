import { Component, ElementRef, Input, OnInit, OnDestroy, HostListener } from '@angular/core';
import {journeyMgmtFaqs } from '../data';
import {ModalService} from '../modal.service';
import {QAndA} from '../q-a';
import { QAndA, QAndA } from 'src/q-a';

@Component({
selector: 'jw-modal',
templateUrl:'modal.component.html'

})

export class ModalComponent implements OnInit{
private element: any;
date=new Date();
questCount:number;
conversation:QAndA[];
helpText:string;
isopneModal:boolean;
isopenDropdown:boolean;
categories;
faqs;

constructor (private modalService; ModalService, private el: ElementRef)
{
    this.element=el.nativeElement;
}
varText='Hello I am your virtual assistant. I am here to answer your questions. How can I help you today? please select screen name in dropdown if you have  query for that particular screen. To get answer please click on question link.';

ngOnInit() : void{
    this.isopenDropdown=false;
    this.isopneModal=false;
    this.helpText="Need Help";
    this.questCount=0;
    this.modalService.getCategories().subscribe(categories=>this.categories= categories);
    this.modalService.getFaqs().subscribe(faqs=>this.faqs=faqs);
    this.conversation=[];
}

toggleHelpButton():void{
this.helpText=this.isopneModal?"Need Help?":"Close";
this.isopneModal=!this.isopneModal;

}

toggleDropdown():void {
this.isopenDropdown=!this.isopenDropdown;
(document.querySelector('#virtual-assistant.va-dropdown ul')as HTMLElement).style.display=this.isopenDropdown?"block":"none";
if(this.isopenDropdown)
(document.querySelector('#vadropdown')as HTMLElement).classList.add("va-dactive");
else
(document.querySelector('#vadropdown')as HTMLElement).classList.remove("va-dactive");

}

updateFaqs(category)
{
    if(category=="Journey Management System"){
        this.faqs=journeyMgmtFaqs;

    }
    this.toggleDropdown();
}

displayConversation(qAndA: QAndA)
{
this.conversation[this.questCount++]=qAndA;
console.log("conversation");
}

displayQAndA1(queationId){
for(let item of this.faqs)
{
    if(item.id==queationId.value){

        let qAndA=new QAndA();
        qAndA.id=this.conversation.length+1;
        qAndA.quest=item.quest;
        qAndA.ans=item.ans;
        this.displayConversation(qAndA);
        queationId.value='';
    }
}

}
}


