import { Component, OnInit, Input } from '@angular/core';
import {journeyMgmtFaqs} from '../data';

@Component({
selector: 'jw-ans',
templateUrl: './ans.component.html'
})

export class AnsComponent implements OnInit
{
@Input() vaText;

@Input() conversation;
 ngOnInit(){}

}
