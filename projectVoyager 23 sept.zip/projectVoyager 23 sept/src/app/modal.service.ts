import {Injectable} from '@angular/core';
import {categories} from './data';
import {faqs} from './data';
import {Observable,of} from 'rxjs';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {Result} from '../Result';
import {map,catchError,tap} from 'rxjs/operators';

const httpOptions = {
    headers : new HttpHeaders({
        'Access-Control-Allow-Origin' : '*',
        'Content-Type' : 'application/json'
    })
}

export class ModalService
{
     /*passwd= "s8YHcz9d";
     "/e2e/apid": {
        "target": "http://www.idliandme.com:5000/",
        "secure": false,
        "changeOrigin": true
      };*/
constructor(private http:HttpClient){

}    
private extractData(res:Response)
{
    let body=res;
    return body || { };
}
getCategories() : Observable<String[]>
{
    return of(categories)
}
getFaqs() : Observable<any>
{
    return of(faqs)

}

getJsonData(question){
    
 return  (this.http.post("http://www.idliandme.com:5000/api/v1/resources/query",
   {
    "query":question   
   })).pipe(
    map(this.extractData));
   
}
}