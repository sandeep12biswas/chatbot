export const categories= ['GAD','FCD','Journey Management System'];
export const faqs=[
    {id:1,quest:'How do I get a replacement Secure Key?',ans:'To replacement Security key simply send us a secure message in internet banking message centre after log on with your existing Security Device.'},
    {id:3,quest:'How can I report a fraud transaction?',ans:'As soon as you learn of the fraud transaction on your accounts, contact our Customer Relationship Center immediately at 800.975.4722.'},
    {id:4,quest:'How can I book an appointment at branch?',ans:'You can either book an appointment through Mobile Banking App or Call our customer care on 1860 266 0811* and schedule your appointment. '},
    {id:5,quest:'Do I need to provide supporting documents to apply for the Cash Credit Plan?',ans:'No. You can withdraw money from your credit card account to your designated personal bank account with no supporting documents.'},
    {id:6,quest:'Where can I find my IBAN?',ans:'You can find your International Bank Account Number (IBAN) on your paper statement or by logging in to Online Banking.'},
    {id:7,quest:'How can I pay cash into my account?',ans:'Deposit machines at your local branch. These machines give you a receipt'},
    {id:8,quest:'How long will it take to get my new credit card?',ans:'Once we receive your application and supporting documents, we will process your application within six working days. If your application is approved, we will send out your new credit card within three working days.'},
    {id:9,quest:'What should I do if I need to dispute a transaction on my debit card?',ans:'Call banks customer service hotline, which you can usually find online or on the back of your debit card. Report the fraudulent charges and provide as much detail as you can'},
    {id:10,quest:'What if I forgot one of my log on details for online banking?',ans:'You can reset any one of your log on details on line by using your security questions and other log on details. Simply follow the appropriate links on the log on pages.'},
    {id:11,quest:'What if I have lost my Secure Key?',ans:'Please contact us on 03457 404 404 so we can deactivate your Digital Secure Key.'}];

    export const journeyMgmtFaqs=[
        {id:1,quest:'How to access Mortgage Offer Documents?',ans:'JMS My Document via RHN'},
        {id:2,quest:'Is application has been completed/submitted to underwiting?',ans:'Yes - Once Underwriting is completed, application status will change to Accept OR No based on application details'},
        {id:3,quest:'How to update D/D details for the mortgage?',ans:'After completing Full Credit Decision, you need to perform Valuation, Direct Debit and Conveyancing. You can complete it in any order.If the page showing valuation as next step , then just launch that function and skip it, it will take you to DD'},
        {id:4,quest:'How to update valuation details for the mortgage?',ans:'After completing Full Credit Decision, you need to perform valuation,Direct Debit and conveyancing. You can compelete it in any order. If valuation details are provided from youe end, then your request is with our valuer and application status would be changed once that done. Thanks for your patience'}

    ]

    export const GAD=[
        {id:1,quest:'Can I save my application and continue it later?',ans:'Yes, of course! All the information you’ve entered is regularly backed up to our servers. You may leave the app or close it at any point. When you return, you can resume from where you left off.'},
        {id:2,quest:'What is a monthly flat rate?',ans:'A monthly flat rate is one of the methods used to calculate the monthly repayment amount for a loan. Most banks and financial institutions adopt this method to provide a fixed monthly repayment.'},
        {id:3,quest:'How much can I borrow?',ans:'You may use the Mortgage Calculator to understand how much you will be able to borrow. This calculation is for illustration and your reference only.'},
        {id:4,quest:'Is there any charge for a Mortgage Application?',ans:'No fee is charged when you apply for a mortgage loan. However, if you have accepted our offer and do not draw down the loan within the period stated in the offer letter, we will charge a cancellation fee of 0.15% of the loan amount'}

    ]
    
    export const FCD=[
        {id:1,quest:'My credit card has been lost or stolen. Who do I contact?',ans:'Don’t worry. Just call us immediately and we’ll take care of it.please call (852) 2233 3000.'},
        {id:2,quest:'What are the main types of mortgages? ',ans:'The most common mortgages are fixed- and adjustable-rate mortgages'},
        {id:3,quest:'How is my homeowners insurance paid? ',ans:'If you have homeowner’s insurance collected as part of your escrow account, bank will receive your insurance invoice and disburse the appropriate funds from your escrow account. Your monthly billing statement will display any disbursements.'},
        {id:4,quest:'How do I use my chip-enabled debit card? ',ans:'You may continue to use your card the same way you do today. If the retailer has a chip-enabled terminal, you may be prompted to insert your chip-enabled card, face up, into the card reader. Make sure you leave your card in the terminal while the entire transaction is processed. You may be prompted to enter your PIN for verification. ATMs work similarly. Be sure to remove your card from the terminal when the transaction is complete.'},
        {id:5,quest:'Can I avoid paying interest on new purchases after transferring a balance?',ans:'If you take advantage of this promotional APR and continue to pay minimum payment plus non-promotional balances, including purchases, cash advance fees and finance charges by the due date, you will not lose your interest-free period.'},
        {id:6,quest:'Can I still place a stop check request? ',ans:'Yes. You can submit a request to stop any check (from the Account Details, select Manage > Stop Check), but if that check has been processed then you will not be able to stop the check.'},
        {id:7,quest:'What is the maximum amount of Balance Transfer I can request?',ans:'You may write the Check(s) or request a Balance Transfer for any amount, but the total amount including any Balance Transfer fees must be less than your available credit limit.'}
    ]

