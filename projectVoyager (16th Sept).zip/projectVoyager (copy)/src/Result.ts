export class Result {
    
    Reply: string;
  }