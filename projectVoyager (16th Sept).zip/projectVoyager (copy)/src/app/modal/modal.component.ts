import { Component, ElementRef, Input, OnInit, OnDestroy, HostListener } from '@angular/core';
import {journeyMgmtFaqs } from '../data';
import {ModalService} from '../modal.service';
import {QAndA} from '../q-a';
import { Result } from 'src/Result';


@Component({
selector: 'jw-modal',
templateUrl:'modal.component.html'

})

export class ModalComponent implements OnInit{
private element: any;
date=new Date();
questCount:number;
conversation:QAndA[];
helpText:string;
//data:string;
isopenModal:boolean;
isopenDropdown:boolean;
categories;
faqs;
result:Result;
information;

constructor (private modalService: ModalService, private el: ElementRef)
{
    this.element=el.nativeElement;
}

vaText=`Hello, I am your virtual assistant. I am here to answer
 your questions. How can I help you today?
 
 Please select screen name in dropdown if you have
 query for that particular screen.
 
 To get answer please click on question link.`;

ngOnInit() : void{
    this.isopenDropdown=false;
    this.isopenModal=false;
    this.helpText="Need Help";
    this.questCount=0;
    this.modalService.getCategories().subscribe(categories=>this.categories= categories);
    this.modalService.getFaqs().subscribe(faqs=>this.faqs=faqs);
    this.getInf("Hi");
    this.conversation=[];
}

toggleHelpButton():void{
this.helpText=this.isopenModal?"Need Help?":"Close";
this.isopenModal=!this.isopenModal;

}

toggleDropdown():void {
this.isopenDropdown=!this.isopenDropdown;
(document.querySelector('#virtual-assistant .va-dropdown ul')as HTMLElement).style.display=this.isopenDropdown?"block":"none";
if(this.isopenDropdown)
(document.querySelector('#vadropdown')as HTMLElement).classList.add("va-dactive");
else
(document.querySelector('#vadropdown')as HTMLElement).classList.remove("va-dactive");

}

updateFaqs(category)
{
    if(category=="Journey Management System"){
        this.faqs=journeyMgmtFaqs;

    }
    this.toggleDropdown();
}

displayConversation(qAndA: QAndA)
{
this.conversation[this.questCount++]=qAndA;
console.log("conversation");
}

getInf(question){
    this.modalService.getJsonData(question).subscribe((data: {}) => {
        console.log("We are here "+JSON.stringify(data));       
        this.information = data;
      });;
}

displayQAndA1(question){
        
        this.getInf(question);
        console.log("Me  "+(JSON.stringify(this.information)));
        console.log("You  "+this.information.Reply);
        let qAndA=new QAndA();
        qAndA.quest=question.value;       
        qAndA.ans=this.information.Reply;        
        this.displayConversation(qAndA);
        question.value='';

}
}


