import { Component, OnInit , Input, Output, EventEmitter} from '@angular/core';
import {journeyMgmtFaqs } from '../data';
import { faqs } from '../data';
import { QAndA } from '../q-a';
@Component({
    selector: "jw-faqs",
    templateUrl: './faqs.component.html'
})

export class FaqsComponent implements OnInit
{

    @Input() faqs: QAndA[];
    count: number;
    @Output() displayQAndAnsReq = new EventEmitter<QAndA>();
    constructor() {}

    ngOnInit(){

        this.count=0;
    }

    displayQAndA(faq:QAndA)
    {
for(let item of this.faqs){
    if(item.quest===faq.quest)
    {
        let qAndA=new QAndA();
        qAndA.id=this.count++;
        qAndA.quest=item.quest;
        qAndA.ans= item.ans;
        this.displayQAndAnsReq.emit(qAndA);
        break;
    }
}

    }
}